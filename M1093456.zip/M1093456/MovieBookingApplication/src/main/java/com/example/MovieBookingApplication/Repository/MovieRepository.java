package com.example.MovieBookingApplication.Repository;

import com.example.MovieBookingApplication.Entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface MovieRepository extends JpaRepository<Movie,Long> {

    @Query(value = "SELECT * FROM MOVIE ORDER BY movie_name",nativeQuery = true)
    public List<Movie> findMovieNameSorted();

    @Query(value = "SELECT * FROM MOVIE ORDER BY release_date",nativeQuery = true)
    public List<Movie> findreleaseDateSorted();

}
