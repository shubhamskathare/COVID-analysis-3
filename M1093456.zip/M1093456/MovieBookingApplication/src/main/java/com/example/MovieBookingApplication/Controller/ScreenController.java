package com.example.MovieBookingApplication.Controller;

import com.example.MovieBookingApplication.Entity.Screen;
import com.example.MovieBookingApplication.Service.ServiceImpl.ScreenServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api")
public class ScreenController {
    @Autowired
    ScreenServiceImpl screenServiceImpl;

    @PostMapping("/addscreen")
    public Screen addScreen(@RequestBody Screen screen) throws JsonProcessingException {
       return screenServiceImpl.addScreen(screen);
    }

    @GetMapping("/getscreenbyid/{screenId}")
    public Screen getScreenById(@PathVariable Long screenId) throws JsonProcessingException {
        return screenServiceImpl.findScreenById(screenId);
    }

    @GetMapping("/getallscreens")
    public List<Screen> getAllScreens() throws JsonProcessingException {
        return screenServiceImpl.getAllScreens();
    }

    @GetMapping("/getallscreenstypesorted")
    public List<Screen> getScreenByTypeSorted() throws JsonProcessingException {
        return screenServiceImpl.getScreenTypeSorted();
    }
    @PatchMapping("/updatescreen")
    public Screen updateScreen(@RequestBody Screen screen) throws JsonProcessingException {
        return screenServiceImpl.updateScreen(screen);
    }
    @DeleteMapping("/deletescreen/{screenId}")
    public void deleteScreen(@PathVariable Long screenId)
    {
         screenServiceImpl.deleteScreen(screenId);
    }
}
