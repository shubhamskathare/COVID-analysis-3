package com.example.MovieBookingApplication.Service;

import com.example.MovieBookingApplication.Entity.BookedSeats;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface BookedSeatsService {
    public BookedSeats saveBookedSeats(BookedSeats booked) throws JsonProcessingException;

    public BookedSeats getBookingById(Long id) throws JsonProcessingException;

    public List<BookedSeats> findAllBookings() throws JsonProcessingException;
    public BookedSeats updateBooking(BookedSeats updatedBooking) throws JsonProcessingException;
    public void deleteBooking(Long id);

    public List<BookedSeats> getseatTypeSorted() throws JsonProcessingException;
    public List<BookedSeats> getNoOfSeatsBookedSorted() throws JsonProcessingException;
    public List<BookedSeats> getdateSorted() throws JsonProcessingException;
}
