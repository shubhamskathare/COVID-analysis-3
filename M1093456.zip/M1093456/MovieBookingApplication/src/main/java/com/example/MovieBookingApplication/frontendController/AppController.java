package com.example.MovieBookingApplication.frontendController;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@AllArgsConstructor
public class AppController {
    @Autowired
    private LoginService loginService;

    @RequestMapping("/")
    public ModelAndView home(ModelMap model)
    {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("login");
        return mv;
    }

    @PostMapping("/")
    public ModelAndView showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password){

        boolean isValidUser = loginService.validate(name, password);
        ModelAndView mv1 = new ModelAndView();
        if (!isValidUser) {
            model.put("errorMessage", "Invalid Credentials");
            mv1.setViewName("login");
            return mv1;
        }

        model.put("name", name);
        model.put("password", password);
        mv1.setViewName("hello");
        return mv1;
    }
}
