package com.example.MovieBookingApplication.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.Serial;

public class NoSuchUserExistsException extends RuntimeException{
	@Serial
    private static final long serialVersionUID = 1L;

}
