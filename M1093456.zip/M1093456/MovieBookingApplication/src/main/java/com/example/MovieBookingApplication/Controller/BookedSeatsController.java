package com.example.MovieBookingApplication.Controller;

import com.example.MovieBookingApplication.Entity.BookedSeats;
import com.example.MovieBookingApplication.Service.ServiceImpl.BookedSeatsServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
public class BookedSeatsController {
    @Autowired
    private BookedSeatsServiceImpl bookedSeatsServiceimpl;
    @PostMapping("/bookingseat")
    private BookedSeats bookingSeat(@RequestBody BookedSeats bookedSeats) throws JsonProcessingException {
        Random r=new Random();
        bookedSeats.setCinemaIfType(cinemaIfType());
        bookedSeats.setAmount(r.nextInt(3000));
        int a=r.nextInt(50);
        bookedSeats.setTotalSeats(a);
        int b=r.nextInt(20);
        bookedSeats.setNoOfSeatsBooked(Math.min(b, a));
        int c=a-b;
        bookedSeats.setSeatsAvailable(Math.max(c, 0));
        bookedSeats.setSeatType(seatType());
        bookedSeats.setDate(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()));
        return bookedSeatsServiceimpl.saveBookedSeats(bookedSeats);
    }
    public String cinemaIfType()
    {
        return new Random().nextBoolean()?"Innox":"Pvr";
    }

    public  String seatType()
    {
        return new Random().nextBoolean()?"Low class":"premium";
    }

    @GetMapping("/findbyid/{bookedSeatsId}")
    public BookedSeats findById(@PathVariable Long bookedSeatsId) throws JsonProcessingException {
        return bookedSeatsServiceimpl.getBookingById(bookedSeatsId);
    }
    @GetMapping("/findallbookings")
    public List<BookedSeats> findAllBookings() throws JsonProcessingException {
        return bookedSeatsServiceimpl.findAllBookings();
    }

    @GetMapping("/displayseattypesorted")
    public List<BookedSeats> displaySeatTypeSorted() throws JsonProcessingException {
        return bookedSeatsServiceimpl.getseatTypeSorted();
    }

    @GetMapping("/displaynoofseatsbookedsorted")
    public List<BookedSeats> displayNoOfSeatsBookedSorted() throws JsonProcessingException {
        return bookedSeatsServiceimpl.getNoOfSeatsBookedSorted();
    }
    @PatchMapping("/updatebooking")
    public BookedSeats updatedBooking(@RequestBody BookedSeats bookedSeats) throws JsonProcessingException {
        return bookedSeatsServiceimpl.updateBooking(bookedSeats);
    }

    @DeleteMapping("/deletebooking/{bookedSeatsId}")
    public void deleteBookingById(@PathVariable Long bookedSeatsId)
    {
         bookedSeatsServiceimpl.deleteBooking(bookedSeatsId);
    }
}
