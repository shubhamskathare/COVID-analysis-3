package com.example.MovieBookingApplication.Service.ServiceImpl;

import com.example.MovieBookingApplication.Dao.impl.InnoxDao;
import com.example.MovieBookingApplication.Entity.Innox;
import com.example.MovieBookingApplication.Exception.NoSuchInnoxExistsException;
import com.example.MovieBookingApplication.Exception.NoSuchUserExistsException;
import com.example.MovieBookingApplication.Repository.InnoxRepository;
import com.example.MovieBookingApplication.Service.InnoxService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@NoArgsConstructor
@AllArgsConstructor
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class InnoxServiceImpl implements InnoxService {

    @Autowired(required = false)
    private InnoxDao innoxDao;


    private final Logger log= LoggerFactory.getLogger(InnoxServiceImpl.class);

    @Override
    public Innox saveInnox(Innox innox) throws JsonProcessingException {
        log.info("Innox Service request : {}",new ObjectMapper().writeValueAsString(innox));
        return innoxDao.save(innox);
    }

    @Override
    public Optional<Innox> getInnoxById(Long innoxId) throws JsonProcessingException {
         Optional<Innox> innox= Optional.ofNullable(innoxDao.get(innoxId).orElseThrow(() -> new NoSuchInnoxExistsException()));
        log.info("Innox Service findInnoxById  : {} ",new ObjectMapper().writeValueAsString(innox));
        return innox;
    }

    @Override
    public List<Innox> getAllInnox() throws JsonProcessingException {
        List<Innox> innox=innoxDao.getAll();
        log.info("Innox Service getAllInnox  : {} ",new ObjectMapper().writeValueAsString(innox));
        return innox;
    }

    @Override
    public Innox updateInnox(Innox innox) throws JsonProcessingException {
        log.info("Innox Service update request : {}",new ObjectMapper().writeValueAsString(innox));
        return innoxDao.update(innox);
    }

    @Override
    public void deleteInnoxById(Long innoxId) {
        innoxDao.delete(innoxId);
    }
}
