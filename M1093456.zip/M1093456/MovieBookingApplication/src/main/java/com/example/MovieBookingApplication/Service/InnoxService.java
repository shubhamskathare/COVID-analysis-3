package com.example.MovieBookingApplication.Service;

import com.example.MovieBookingApplication.Entity.Innox;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;
import java.util.Optional;

public interface InnoxService {

    public Innox saveInnox(Innox innox) throws JsonProcessingException;
    public Optional<Innox> getInnoxById(Long innoxId) throws JsonProcessingException;
    public List<Innox> getAllInnox() throws JsonProcessingException;
    public Innox updateInnox(Innox innox) throws JsonProcessingException;
    public void deleteInnoxById(Long innoxId);

}
