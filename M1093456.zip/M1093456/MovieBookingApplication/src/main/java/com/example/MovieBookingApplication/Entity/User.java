package com.example.MovieBookingApplication.Entity;

import lombok.*;
import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@AllArgsConstructor
@Getter
@Setter
@ToString
@NoArgsConstructor
@Table(name = "user")
public class User implements Comparable<User>{
    @Id
    @GeneratedValue
    @Column(name="user_id")
    private Long userId;
    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;
    @Column(name = "password")
    private String password;

    @OneToMany(cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<Innox> innox;

    @OneToMany(cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<Pvr> pvr;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null)
            return false;
        if (getClass() != o.getClass())
            return false;
          User user = (User) o;
        return Objects.equals(userId, user.userId) && Objects.equals(name,user.name) && Objects.equals(email,user.email)  && Objects.equals(password, user.password) &&Objects.equals(innox, user.innox) && Objects.equals(pvr, user.pvr);
    }

    @Override
    public int hashCode() {
        final int prime=5;
        int result=1;
        result = prime * result + ((name==null) ? 0 : name.hashCode());
        result = (int)(prime * result + userId);
        result = prime * result +((email==null) ? 0 : email.hashCode());
        result = prime * result + ((password==null) ? 0 : password.hashCode());
        return result;
    }

   @Override
    public int compareTo(User o) {
        return this.email.compareTo(o.email);
    }
}
