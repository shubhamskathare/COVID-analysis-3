package com.example.MovieBookingApplication.Repository;

import com.example.MovieBookingApplication.Entity.BookedSeats;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface BookedSeatsRepository extends JpaRepository<BookedSeats,Long> {
    @Query(value = "SELECT * FROM BOOKEDSEATS ORDER BY seat_type",nativeQuery = true)
    public List<BookedSeats> findseatTypeSorted();

    @Query(value = "SELECT * FROM BOOKEDSEATS ORDER BY no_of_seats_booked",nativeQuery = true)
    public List<BookedSeats> findNoOfSeatsBookedSorted();

    @Query(value = "SELECT * FROM BOOKEDSEATS ORDER BY date",nativeQuery = true)
    public List<BookedSeats> finddateSorted();

    @Query(value = "SELECT * FROM BOOKEDSEATS ORDER BY total_seats",nativeQuery = true)
    public List<BookedSeats> findtotalSeatsSorted();

    @Query(value = "SELECT * FROM BOOKEDSEATS ORDER BY seats_available",nativeQuery = true)
    public List<BookedSeats> findseatsAvailableSorted();

}
