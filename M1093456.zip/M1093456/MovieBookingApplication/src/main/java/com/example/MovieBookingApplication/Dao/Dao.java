package com.example.MovieBookingApplication.Dao;

import java.util.List;
import java.util.Optional;

public interface Dao<T> {
    List<T> getAll();
    Optional<T> get(Long id);
    T save(T t);
    T update(T t);
    void delete(Long id);
}
