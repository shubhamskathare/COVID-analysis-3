package com.example.MovieBookingApplication.Entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Innox implements CinemaIF,Comparable<Innox>{
    @Id
    @GeneratedValue
    @Column(name = "innox_id")
    private Long innoxId;

    @OneToMany(cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<Screen> screen;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Innox innox = (Innox) o;
        return Objects.equals(innoxId, innox.innoxId) && Objects.equals(screen, innox.getScreen());
    }

    @Override
    public int hashCode() {
        final int prime =5;
        int result=1;
        result = (int)(prime * result +innoxId);
        return result;
    }



    @Override
    public int compareTo(Innox o) {
        if(innoxId>o.innoxId)
            return 1;
        else  if(Objects.equals(innoxId, o.innoxId))
            return 0;
        else
            return -1;
    }

}
