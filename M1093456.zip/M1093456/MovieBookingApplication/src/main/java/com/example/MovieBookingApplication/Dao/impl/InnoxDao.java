package com.example.MovieBookingApplication.Dao.impl;

import com.example.MovieBookingApplication.Dao.Dao;
import com.example.MovieBookingApplication.Entity.Innox;
import com.example.MovieBookingApplication.Repository.InnoxRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class InnoxDao implements Dao<Innox>{
    @Autowired
    InnoxRepository innoxRepository;

        @Override
        public List<Innox> getAll() {
            return innoxRepository.findAll();
        }

        @Override
        public Optional<Innox> get(Long id) {
            return innoxRepository.findById(id);
        }

        @Override
        public Innox save(Innox innoxDao) {
            return innoxRepository.save(innoxDao);
        }

        @Override
        public Innox update(Innox innoxDao) {
            return innoxRepository.save(innoxDao);
        }

        @Override
        public void delete(Long id) {
            innoxRepository.deleteById(id);
        }
}


