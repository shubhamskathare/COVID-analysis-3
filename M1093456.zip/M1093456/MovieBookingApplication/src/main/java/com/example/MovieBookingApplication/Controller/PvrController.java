package com.example.MovieBookingApplication.Controller;

import com.example.MovieBookingApplication.Entity.Pvr;
import com.example.MovieBookingApplication.Service.ServiceImpl.PvrServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
public class PvrController {
    @Autowired
    private PvrServiceImpl pvrServiceimpl;

    @PostMapping("/addpvr")
    public Pvr addPvr(@RequestBody Pvr pvr) throws JsonProcessingException {
        return pvrServiceimpl.savePvr(pvr);
    }
    @GetMapping("/getpvr/{pvrId}")
    public Optional<Pvr> getPvrById(@PathVariable Long pvrId) throws JsonProcessingException {
        return pvrServiceimpl.getPvrById(pvrId);
    }
    @GetMapping("/getallpvr")
    public List<Pvr> getAllPvr() throws JsonProcessingException {
        return pvrServiceimpl.getAllPvr();
    }
    @PatchMapping("/updatepvr")
    public Pvr updatePvr(@RequestBody Pvr pvr) throws JsonProcessingException {
        return pvrServiceimpl.updatePvr(pvr);
    }
    @DeleteMapping("/deletepvr/{pvrId}")
    public void deletePvrById(@PathVariable Long pvrId)
    {
        pvrServiceimpl.deletePvrById(pvrId);
    }
}
