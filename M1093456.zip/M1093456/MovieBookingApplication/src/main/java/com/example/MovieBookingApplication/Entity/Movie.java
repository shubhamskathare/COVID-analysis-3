package com.example.MovieBookingApplication.Entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.Objects;


@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "movie")
public class Movie implements Comparable<Movie>{
    @Id
    @GeneratedValue
    @Column(name = "movie_id")
    private Long movieId;
    @Column(name = "movie_name")
    private String movieName;
    @Column(name = "release_date")
    private String releaseDate;
    @Column(name = "show_cycle")
    private int showCycle;



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Movie movie = (Movie) o;
        return Objects.equals(movieId, movie.movieId) && Objects.equals(movieName, movie.movieName) && Objects.equals(releaseDate, movie.releaseDate) && (showCycle== movie.showCycle);
    }

    @Override
    public int hashCode() {
        final int prime=5;
        int result=1;
        result = prime * result + ((movieName==null) ? 0 : movieName.hashCode());
        result = (int)(prime * result +movieId);
        result = prime * result + ((releaseDate==null) ? 0 : releaseDate.hashCode());
        result = (prime * result + showCycle);
        return result;
    }
    @Override
    public int compareTo(Movie o) {
        return this.movieName.compareTo(o.movieName);
    }
}