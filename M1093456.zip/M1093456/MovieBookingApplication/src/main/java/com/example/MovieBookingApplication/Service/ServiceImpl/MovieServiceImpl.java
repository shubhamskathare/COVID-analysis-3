package com.example.MovieBookingApplication.Service.ServiceImpl;

import com.example.MovieBookingApplication.Dao.impl.MovieDao;
import com.example.MovieBookingApplication.Exception.NoSuchMovieExistsException;
import com.example.MovieBookingApplication.Entity.Movie;
import com.example.MovieBookingApplication.Repository.MovieRepository;
import com.example.MovieBookingApplication.Service.MovieService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@AllArgsConstructor
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class MovieServiceImpl implements MovieService {
    @Autowired
   private MovieDao movieDao;
    private final Logger log= LoggerFactory.getLogger(MovieServiceImpl.class);
    @Override
    public Movie addMovie(Movie movie) throws JsonProcessingException {
        Movie movie1=movieDao.save(movie);
        log.info("Movie Service request : {}",new ObjectMapper().writeValueAsString(movie1));
        return movie1;
    }

    @Override
    public Movie displayMovieDetailsById(Long movieId) throws JsonProcessingException {
        Movie movie=movieDao.get(movieId).orElseThrow(()-> new NoSuchMovieExistsException());
        log.info("Movie Service displayMovieDetailsById request : {}",new ObjectMapper().writeValueAsString(movie));
        return movie;
    }

    @Override
    public List<Movie> getAllMovies() throws JsonProcessingException {
        List<Movie> movie=movieDao.getAll();
        log.info("Movie Service getAllMovies request : {}",new ObjectMapper().writeValueAsString(movie));
        return movie;
    }

    @Override
    public Movie updateMovieDetails(Movie movie) throws JsonProcessingException {
        log.info("Movie Service update request : {}",new ObjectMapper().writeValueAsString(movie));
        return movieDao.update(movie);
    }

    @Override
    public void deleteMovie(Long movieId) {
         movieDao.delete(movieId);
    }

    @Override
    public List<Movie> getMovieNameSorted() throws JsonProcessingException {
        List<Movie> movie=movieDao.getMovieNameSorted();
        log.info("Movie Service getAllMovies request : {}",new ObjectMapper().writeValueAsString(movie));
        return movie;
    }

    @Override
    public List<Movie> getReleaseDateSorted() throws JsonProcessingException {
        List<Movie> movie=movieDao.getReleaseDateSorted();
        log.info("Movie Service getAllMovies request : {}",new ObjectMapper().writeValueAsString(movie));
        return movie;
    }


}
