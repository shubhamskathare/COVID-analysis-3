package com.example.MovieBookingApplication.frontendController;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
    public boolean validate(String name,String password)
    {
        return name.equalsIgnoreCase("sujini")&&password.equalsIgnoreCase("vegi");
    }

}
