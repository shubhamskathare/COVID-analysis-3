package com.example.MovieBookingApplication.Service;

import com.example.MovieBookingApplication.Entity.Pvr;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;
import java.util.Optional;

public interface PvrService {

    public Pvr savePvr(Pvr pvr) throws JsonProcessingException;
    public Optional<Pvr> getPvrById(Long pvrId) throws JsonProcessingException;
    public List<Pvr> getAllPvr() throws JsonProcessingException;
    public Pvr updatePvr(Pvr pvr) throws JsonProcessingException;
    public void deletePvrById(Long pvrId);

}
