package com.example.MovieBookingApplication.Dao.impl;

import com.example.MovieBookingApplication.Dao.Dao;
import com.example.MovieBookingApplication.Entity.Screen;
import com.example.MovieBookingApplication.Repository.ScreenRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class ScreenDao implements Dao<Screen> {

    @Autowired
    ScreenRepository screenRepository;

    @Override
    public List<Screen> getAll() {
        return screenRepository.findAll();
    }

    @Override
    public Optional<Screen> get(Long id) {
        return screenRepository.findById(id);
    }

    @Override
    public Screen save(Screen screen) {
        return screenRepository.save(screen);
    }


    public List<Screen> findScreenTypeSorted()
    {
        return screenRepository.findByScreenTypeSorted();
    }

    @Override
    public Screen update(Screen screen) {
        return screenRepository.save(screen);
    }

    @Override
    public void delete(Long id) {
          screenRepository.deleteById(id);
    }
}

