package com.example.MovieBookingApplication.Entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.Objects;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "screen")
public class Screen implements Comparable<Screen>{
    @Id
    @GeneratedValue
    @Column(name = "screen_id")
    private Long screenId;
    @Column(name = "screen_type")
    private String screenType;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "movie_id",referencedColumnName = "movie_id")
    @ToString.Exclude
    private Movie movie;


    @Override
    public int compareTo(Screen o) {
        return this.screenType.compareTo(o.screenType);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Screen screen = (Screen) o;
        return Objects.equals(screenId, screen.screenId) && Objects.equals(screenType, screen.screenType) && Objects.equals(movie, screen.movie);
    }

    @Override
    public int hashCode() {
        final int prime=5;
        int result=1;
        result = prime * result + ((screenType==null) ? 0 : screenType.hashCode());
        result = (int)(prime * result + screenId);
        return result;
    }
}