package com.example.MovieBookingApplication.Repository;

import com.example.MovieBookingApplication.Entity.Innox;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InnoxRepository extends JpaRepository<Innox,Long> {

}
