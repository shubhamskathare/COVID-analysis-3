package com.example.MovieBookingApplication.Service.ServiceImpl;

import com.example.MovieBookingApplication.Dao.impl.UserDao;
import com.example.MovieBookingApplication.Entity.User;
import com.example.MovieBookingApplication.Exception.NoSuchUserExistsException;
import com.example.MovieBookingApplication.Service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

@Service
@AllArgsConstructor
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class UserServiceImpl implements UserService {

    @Autowired
private UserDao userDao;

    private final Logger log= LoggerFactory.getLogger(UserServiceImpl.class);
    @Override
    public User addUser(User user) throws JsonProcessingException {
        log.info("UserService request : {}",new ObjectMapper().writeValueAsString(user));
        return userDao.save(user);
    }

    @Override
    public User findUserById(Long userId) throws JsonProcessingException {
        User user=userDao.get(userId).orElseThrow(()-> new NoSuchUserExistsException());
        log.info("User Service findUserById  : {} ",new ObjectMapper().writeValueAsString(user));
        return user;
    }

    @Override
    public User update(User user) throws JsonProcessingException {
        log.info("UserService update request : {}",new ObjectMapper().writeValueAsString(user));
        return userDao.save(user);
    }

    @Override
    public void delete(Long userId)
    {
        userDao.delete(userId);
    }
    @Override
    public List<User> getUsers() throws JsonProcessingException {
        List<User> user=userDao.getAll();
        log.info("User Service get all users  : {} ",new ObjectMapper().writeValueAsString(user));
        return user;
    }

    @Override
    public User getUsersByName(String name) throws JsonProcessingException {
        log.info("User Service get all users  : {} ",new ObjectMapper().writeValueAsString(name));
        return userDao.getByName(name);
    }


}
