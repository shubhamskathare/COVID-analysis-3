package com.example.MovieBookingApplication.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "pvr")
public class Pvr implements CinemaIF,Comparable<Pvr>{
    @Id
    @GeneratedValue
    @Column(name="pvr_id")
    private Long pvrId;


    @OneToMany(cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<Screen> screen;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Pvr pvr = (Pvr) o;
        return Objects.equals(pvrId, pvr.pvrId) && Objects.equals(screen,pvr.screen);
    }

    @Override
    public int hashCode() {
        final int prime =5;
        int result=1;
        result = (int)(prime * result +pvrId);
        return result;
    }



    @Override
    public int compareTo(Pvr o) {
        if(pvrId >o.pvrId)
            return 1;
        else if(Objects.equals(pvrId, o.pvrId))
            return 0;
        else
            return -1;
    }

}
