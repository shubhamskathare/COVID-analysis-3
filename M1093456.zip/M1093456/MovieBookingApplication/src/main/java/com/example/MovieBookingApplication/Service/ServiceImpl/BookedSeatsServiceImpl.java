package com.example.MovieBookingApplication.Service.ServiceImpl;

import com.example.MovieBookingApplication.Dao.impl.BookedSeatsDao;
import com.example.MovieBookingApplication.Entity.BookedSeats;
import com.example.MovieBookingApplication.Exception.NoSuchBookingExistsException;
import com.example.MovieBookingApplication.Service.BookedSeatsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@AllArgsConstructor
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class BookedSeatsServiceImpl implements BookedSeatsService {
@Autowired
   private BookedSeatsDao bookedSeatsDao;

    private final Logger log= LoggerFactory.getLogger(BookedSeatsServiceImpl.class);
    @Override
    public BookedSeats saveBookedSeats(BookedSeats booked) throws JsonProcessingException {
        log.info("Booked seats Service request : {}",new ObjectMapper().writeValueAsString(booked));
        return bookedSeatsDao.save(booked);
    }

    @Override
    public BookedSeats getBookingById(Long bookedSeatsId) throws JsonProcessingException {
        BookedSeats bookedSeats=bookedSeatsDao.get(bookedSeatsId).orElseThrow(()->new NoSuchBookingExistsException());
        log.info("Booked seats getBookingById Service request : {}",new ObjectMapper().writeValueAsString(bookedSeats));
        return bookedSeats;
    }

    @Override
    public List<BookedSeats> findAllBookings() throws JsonProcessingException {
       List<BookedSeats> bookedSeats=bookedSeatsDao.getAll();
        log.info("Booked seats findAllBookings Service request : {}",new ObjectMapper().writeValueAsString(bookedSeats));
        return bookedSeats;
    }

    @Override
    public BookedSeats updateBooking(BookedSeats updatedBooking) throws JsonProcessingException {
        log.info("Booked seats Service request : {}",new ObjectMapper().writeValueAsString(updatedBooking));
        return bookedSeatsDao.update(updatedBooking);
    }
    @Override
    public void deleteBooking(Long bookedSeatsId) {
       bookedSeatsDao.delete(bookedSeatsId);
    }

    @Override
    public List<BookedSeats> getseatTypeSorted() throws JsonProcessingException {
        List<BookedSeats> bookedSeats=bookedSeatsDao.getseatTypeSorted();
        log.info("Booked seats findAllBookings Service request : {}",new ObjectMapper().writeValueAsString(bookedSeats));
        return bookedSeats;
    }

    @Override
    public List<BookedSeats> getNoOfSeatsBookedSorted() throws JsonProcessingException {
        List<BookedSeats> bookedSeats=bookedSeatsDao.getNoOfSeatsBookedSorted();
        log.info("Booked seats findAllBookings Service request : {}",new ObjectMapper().writeValueAsString(bookedSeats));
        return bookedSeats;
    }

    @Override
    public List<BookedSeats> getdateSorted() throws JsonProcessingException {
        List<BookedSeats> bookedSeats=bookedSeatsDao.getdateSorted();
        log.info("Booked seats findAllBookings Service request : {}",new ObjectMapper().writeValueAsString(bookedSeats));
        return bookedSeats;
    }


}
