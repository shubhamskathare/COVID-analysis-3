package com.example.MovieBookingApplication.Dao.impl;

import com.example.MovieBookingApplication.Dao.Dao;
import com.example.MovieBookingApplication.Entity.Pvr;
import com.example.MovieBookingApplication.Repository.PvrRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class PvrDao implements Dao<Pvr> {

    @Autowired
    PvrRepository pvrRepository;

    @Override
    public List<Pvr> getAll() {
        return pvrRepository.findAll();
    }

    @Override
    public Optional<Pvr> get(Long id) {
        return pvrRepository.findById(id);
    }

    @Override
    public Pvr save(Pvr pvrDao) {
        return pvrRepository.save(pvrDao);
    }

    @Override
    public Pvr update(Pvr pvrDao) {
        return pvrRepository.save(pvrDao);
    }

    @Override
    public void delete(Long id) {
        pvrRepository.deleteById(id);
    }
}
