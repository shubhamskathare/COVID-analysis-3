package com.example.MovieBookingApplication.frontendController;

import com.example.MovieBookingApplication.Service.ServiceImpl.BookedSeatsServiceImpl;
import com.example.MovieBookingApplication.Service.ServiceImpl.MovieServiceImpl;
import com.example.MovieBookingApplication.Service.ServiceImpl.ScreenServiceImpl;
import com.example.MovieBookingApplication.Service.ServiceImpl.UserServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@AllArgsConstructor
public class UserDetailsController {
    @Autowired
    private UserServiceImpl userServiceimpl;
    @Autowired
    private MovieServiceImpl movieServiceimpl;
    @Autowired
    private ScreenServiceImpl screenServiceimpl;
    @Autowired
    private BookedSeatsServiceImpl bookedSeatsServiceimpl;

    @GetMapping({"/hello","/hello"})
    public String hello(@RequestParam(value = "name",defaultValue = "sujini",required = true) String name, Model model) throws JsonProcessingException {
           model.addAttribute("name",userServiceimpl.getUsersByName(name));
           model.addAttribute("allusers",userServiceimpl.getUsers());
           model.addAttribute("movienamessorted",movieServiceimpl.getAllMovies());
           model.addAttribute("screentypesorted",screenServiceimpl.getAllScreens());
           model.addAttribute("bookedSeats",bookedSeatsServiceimpl.findAllBookings());
           return "hello";
    }

}
