package com.example.MovieBookingApplication.Entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name = "bookedseats")
public class BookedSeats implements Comparable<BookedSeats>{

        @Id
        @GeneratedValue
        private Long bookedSeatsId;
        private Long movieId;
        private Long userId;
        private Long screenId;
        private String cinemaIfType;
        private int amount;
        private String date;
        private String seatType;
        private int totalSeats;
        private int noOfSeatsBooked;
        private int seatsAvailable;
        @Override
        public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
                BookedSeats that = (BookedSeats) o;
                return Objects.equals(bookedSeatsId, that.bookedSeatsId) && Objects.equals(cinemaIfType, that.cinemaIfType) && Objects.equals(movieId, that.movieId) && Objects.equals(userId, that.userId) && Objects.equals(screenId, that.screenId) && Objects.equals(amount, that.amount) && Objects.equals(date, that.date)  && Objects.equals(seatType, that.seatType) && Objects.equals(totalSeats, that.totalSeats) && Objects.equals(noOfSeatsBooked, that.noOfSeatsBooked) && Objects.equals(seatsAvailable, that.seatsAvailable);
        }


        @Override
        public int compareTo(BookedSeats o) {
                if(bookedSeatsId >o.bookedSeatsId)
                        return 1;
                else if(Objects.equals(bookedSeatsId, o.bookedSeatsId))
                        return 0;
                else
                        return -1;
        }



        @Override
        public int hashCode() {
                final int prime=5;
                int result=1;
                result = (int)(prime * result + bookedSeatsId);
                result = (int)(prime * result + movieId);
                result = (int)(prime * result + userId);
                result = (int)(prime * result + screenId);
                result = (prime * result + amount);
                result = (prime * result + totalSeats);
                result = (prime * result + noOfSeatsBooked);
                result = (prime * result + seatsAvailable);
                result = prime * result +((cinemaIfType==null) ? 0 : cinemaIfType.hashCode());
                result = prime * result + ((date==null) ? 0 : date.hashCode());
                result = prime * result + ((seatType==null) ? 0 : seatType.hashCode());
                return result;
        }
}
