package com.example.MovieBookingApplication.Controller;

import com.example.MovieBookingApplication.Entity.Movie;
import com.example.MovieBookingApplication.Service.ServiceImpl.MovieServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api")
public class MovieController {
    @Autowired
    MovieServiceImpl movieServiceImpl;

    @PostMapping("/addmovie")
    public Movie addingMovie(@RequestBody Movie movie) throws JsonProcessingException {
        return movieServiceImpl.addMovie(movie);
    }

    @GetMapping("/displaymoviedetails/{movieId}")
    public Movie displayMovieDetails(@PathVariable Long movieId) throws JsonProcessingException {
        return movieServiceImpl.displayMovieDetailsById(movieId);
    }

    @GetMapping("/displayallmovies")
    public List<Movie> displayAllMovies() throws JsonProcessingException {
        return movieServiceImpl.getAllMovies();
    }

    @GetMapping("/displaymovienamesorted")
    public List<Movie> displayMovieNameSorted() throws JsonProcessingException {
        return movieServiceImpl.getMovieNameSorted();
    }

    @GetMapping("/displayreleasedatesorted")
    public List<Movie> displayReleaseDateSorted() throws JsonProcessingException {
        return movieServiceImpl.getReleaseDateSorted();
    }

    @PatchMapping("/updatemoviedetails")
    public Movie updateMovieDetails(@RequestBody Movie movie) throws JsonProcessingException {
        return movieServiceImpl.updateMovieDetails(movie);
    }

    @DeleteMapping("/deletemoviedetails/{movieId}")
    public void deleteMovieDetails(@PathVariable Long movieId)
    {
         movieServiceImpl.deleteMovie(movieId);
    }
}
