package com.example.MovieBookingApplication.Service;

import com.example.MovieBookingApplication.Entity.User;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface UserService {
    public User addUser(User user) throws JsonProcessingException;
    public User findUserById(Long userId) throws JsonProcessingException;

    public List<User> getUsers() throws JsonProcessingException;
    public User getUsersByName(String name) throws JsonProcessingException;
    public User update(User user) throws JsonProcessingException;
    public void delete(Long id) ;

}
