package com.example.MovieBookingApplication.Service;

import com.example.MovieBookingApplication.Entity.Screen;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface ScreenService {
    public Screen addScreen(Screen screen) throws JsonProcessingException;
    public Screen findScreenById(Long screenId) throws JsonProcessingException;
    public List<Screen> getAllScreens() throws JsonProcessingException;
    public List<Screen> getScreenTypeSorted() throws JsonProcessingException;
    public Screen updateScreen(Screen screen) throws JsonProcessingException;
    public void deleteScreen(Long screenId);

}
