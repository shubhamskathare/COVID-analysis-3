package com.example.MovieBookingApplication.Service.ServiceImpl;

import com.example.MovieBookingApplication.Dao.impl.PvrDao;
import com.example.MovieBookingApplication.Entity.Pvr;
import com.example.MovieBookingApplication.Exception.NoSuchInnoxExistsException;
import com.example.MovieBookingApplication.Exception.NoSuchPvrExistsException;
import com.example.MovieBookingApplication.Repository.PvrRepository;
import com.example.MovieBookingApplication.Service.PvrService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class PvrServiceImpl implements PvrService {

    @Autowired(required = false)
    private PvrDao pvrDao;

    private final Logger log= LoggerFactory.getLogger(PvrServiceImpl.class);
    @Override
    public Pvr savePvr(Pvr pvr) throws JsonProcessingException {
        log.info("Pvr Service request : {}",new ObjectMapper().writeValueAsString(pvr));
        return pvrDao.save(pvr);
    }

    @Override
    public Optional<Pvr> getPvrById(Long pvrId) throws JsonProcessingException {
         Optional<Pvr> pvr= Optional.ofNullable(pvrDao.get(pvrId).orElseThrow(() -> new NoSuchPvrExistsException()));
        log.info("Pvr Service findPvrById  : {} ",new ObjectMapper().writeValueAsString(pvr));
        return pvr;
    }

    @Override
    public List<Pvr> getAllPvr() throws JsonProcessingException {
        List<Pvr> pvr=pvrDao.getAll();
        log.info("Pvr Service getAllPvr  : {} ",new ObjectMapper().writeValueAsString(pvr));
        return pvr;
    }

    @Override
    public Pvr updatePvr(Pvr pvr) throws JsonProcessingException {
        log.info("Pvr Service Updated request : {}",new ObjectMapper().writeValueAsString(pvr));
        return pvrDao.update(pvr);
    }

    @Override
    public void deletePvrById(Long pvrId) {
         pvrDao.delete(pvrId);
    }
}
