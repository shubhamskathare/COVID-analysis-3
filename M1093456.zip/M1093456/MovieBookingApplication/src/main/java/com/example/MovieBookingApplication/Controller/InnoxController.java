package com.example.MovieBookingApplication.Controller;

import com.example.MovieBookingApplication.Entity.Innox;
import com.example.MovieBookingApplication.Service.ServiceImpl.InnoxServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
@NoArgsConstructor
public class InnoxController {

    @Autowired
    private InnoxServiceImpl innoxServiceimpl;


    @PostMapping("/addinnox")
    public Innox addInnox(@RequestBody Innox innox) throws JsonProcessingException {
        return   innoxServiceimpl.saveInnox(innox);
    }

    @GetMapping("/getinnoxbyid/{innoxId}")
    public Optional<Innox> getInnoxById(@PathVariable Long innoxId) throws JsonProcessingException {
        return innoxServiceimpl.getInnoxById(innoxId);
    }

    @GetMapping("/getallinnox")
    public List<Innox> getAllInnox() throws JsonProcessingException {
        return innoxServiceimpl.getAllInnox();
    }

    @PatchMapping("/updateinnox")
    public Innox updateInnox(@RequestBody Innox innox) throws JsonProcessingException {
        return innoxServiceimpl.updateInnox(innox);
    }

    @DeleteMapping("/deleteinnox/{innoxid}")
    public void deleteInnox(@PathVariable Long innoxId)
    {
         innoxServiceimpl.deleteInnoxById(innoxId);
    }

}
