package com.example.MovieBookingApplication.Exception;

import com.example.MovieBookingApplication.Service.ServiceImpl.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class AllExceptionsHandler {

    private final Logger log1= LoggerFactory.getLogger(UserServiceImpl.class);
    private final Logger log2= LoggerFactory.getLogger(ScreenServiceImpl.class);
    private final Logger log3= LoggerFactory.getLogger(PvrServiceImpl.class);
    private final Logger log4= LoggerFactory.getLogger(InnoxServiceImpl.class);
    private final Logger log5= LoggerFactory.getLogger(MovieServiceImpl.class);
    private final Logger log6= LoggerFactory.getLogger(BookedSeatsServiceImpl.class);

    @ExceptionHandler(value = NoSuchUserExistsException.class)
    public ResponseEntity<Object> NoSuchUserExistsException(NoSuchUserExistsException exception){
        String name="Give correct user id";
        log1.error("Exception in user. Message - {}",name);
        return new ResponseEntity<Object>("User Id is not found in the database.", HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = NoSuchScreenExistsException.class)
    public ResponseEntity<Object> NoSuchScreenExistsException(NoSuchScreenExistsException exception){
        String name="Give correct screen id";
        log2.error("Exception in Screen. Message - {}",name);
        return new ResponseEntity<Object>("Screen Id is not found in the database.", HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(value = NoSuchMovieExistsException.class)
    public ResponseEntity<Object> NoSuchMovieExistsException(NoSuchMovieExistsException exception){
        String name="Give correct movie id";
        log3.error("Exception in Movie. Message - {}",name);
        return new ResponseEntity<Object>("Movie Id is not found in the database.", HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(value = NoSuchBookingExistsException.class)
    public ResponseEntity<Object> NoSuchBookingExistsException(NoSuchBookingExistsException exception){
        String name="Give correct booking seats id";
        log4.error("Exception in Booking. Message - {}",name);
        return new ResponseEntity<Object>("Booking Id is not found in the database.", HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = NoSuchInnoxExistsException.class)
    public ResponseEntity<Object> NoSuchInnoxExistsException(NoSuchInnoxExistsException exception){
        String name="Give correct innox id";
        log5.error("Exception in Innox. Message - {}",name);
        return new ResponseEntity<Object>("Innox Id is not found in the database.", HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = NoSuchPvrExistsException.class)
    public ResponseEntity<Object> NoSuchPvrExistsException(NoSuchPvrExistsException exception){
        String name="Give correct pvr id";
        log6.error("Exception in Pvr. Message - {}",name);
        return new ResponseEntity<Object>("Pvr Id is not found in the database.", HttpStatus.NOT_FOUND);
    }
}
