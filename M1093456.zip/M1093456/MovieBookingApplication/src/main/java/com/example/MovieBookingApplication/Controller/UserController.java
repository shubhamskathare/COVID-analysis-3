package com.example.MovieBookingApplication.Controller;

import com.example.MovieBookingApplication.Entity.User;
import com.example.MovieBookingApplication.Service.ServiceImpl.UserServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
public class UserController {

    @Autowired
    UserServiceImpl userServiceImpl;

    @PostMapping("/registeruser")
    public User registerUser(@RequestBody User user) throws JsonProcessingException {
        return userServiceImpl.addUser(user);
    }

    @GetMapping("/getuser/{userId}")
    public User getUserById(@PathVariable Long userId) throws JsonProcessingException {
        return userServiceImpl.findUserById(userId);
    }

    @GetMapping("/displayallusers")
    public List<User> getAllUsers() throws JsonProcessingException {
        return userServiceImpl.getUsers();
    }

    @GetMapping("/getname/{name}")
    public User getUserByName(@PathVariable String name) throws JsonProcessingException {
        return userServiceImpl.getUsersByName(name);
    }
    @PatchMapping("/update")
    public User updateUser(@RequestBody User user) throws JsonProcessingException {
        return userServiceImpl.update(user);
    }

    @DeleteMapping("/delete/{userId}")
    public void deleteUser(@PathVariable Long userId)
    {
        userServiceImpl.delete(userId);
    }
}
