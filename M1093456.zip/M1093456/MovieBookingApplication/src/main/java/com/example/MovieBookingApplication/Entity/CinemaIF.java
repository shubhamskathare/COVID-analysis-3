package com.example.MovieBookingApplication.Entity;

import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Inheritance(strategy = InheritanceType.JOINED)
public interface CinemaIF {
}
