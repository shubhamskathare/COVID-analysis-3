package com.example.MovieBookingApplication.Dao.impl;

import com.example.MovieBookingApplication.Dao.Dao;
import com.example.MovieBookingApplication.Entity.BookedSeats;
import com.example.MovieBookingApplication.Repository.BookedSeatsRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class BookedSeatsDao implements Dao<BookedSeats> {

    @Autowired
    BookedSeatsRepository bookedSeatsRepository;


    @Override
    public List<BookedSeats> getAll() {
        return bookedSeatsRepository.findAll();
    }

    @Override
    public Optional<BookedSeats> get(Long id) {
        return bookedSeatsRepository.findById(id);
    }

    @Override
    public BookedSeats save(BookedSeats bookedSeats) {
        return bookedSeatsRepository.save(bookedSeats);
    }

    @Override
    public BookedSeats update(BookedSeats bookedSeats) {
        return bookedSeatsRepository.save(bookedSeats);
    }

    @Override
    public void delete(Long id) {
         bookedSeatsRepository.deleteById(id);
    }

    public List<BookedSeats> getseatTypeSorted()
    {
        return bookedSeatsRepository.findseatTypeSorted();
    }
    public List<BookedSeats> getNoOfSeatsBookedSorted()
    {
        return bookedSeatsRepository.findNoOfSeatsBookedSorted();
    }
    public List<BookedSeats> getdateSorted()
    {
        return bookedSeatsRepository.finddateSorted();
    }
}
