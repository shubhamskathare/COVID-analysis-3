package com.example.MovieBookingApplication.Service;

import com.example.MovieBookingApplication.Entity.Movie;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;

public interface MovieService {
    public Movie addMovie(Movie movie) throws JsonProcessingException;
    public Movie displayMovieDetailsById(Long movieId) throws JsonProcessingException;
    public List<Movie> getAllMovies() throws JsonProcessingException;
    public Movie updateMovieDetails(Movie movie) throws JsonProcessingException;
    public void deleteMovie(Long movieId);
    public List<Movie> getMovieNameSorted() throws JsonProcessingException;
    public List<Movie> getReleaseDateSorted() throws JsonProcessingException;

}
