package com.example.MovieBookingApplication.Service.ServiceImpl;

import com.example.MovieBookingApplication.Dao.impl.ScreenDao;
import com.example.MovieBookingApplication.Entity.Screen;
import com.example.MovieBookingApplication.Exception.NoSuchScreenExistsException;
import com.example.MovieBookingApplication.Service.ScreenService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@AllArgsConstructor
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class ScreenServiceImpl implements ScreenService {
    @Autowired
    private ScreenDao screenDao;
    private final Logger log= LoggerFactory.getLogger(ScreenServiceImpl.class);

    @Override
    public Screen addScreen(Screen screen) throws JsonProcessingException {
        log.info("Screen Service request : {}",new ObjectMapper().writeValueAsString(screen));
        return screenDao.save(screen);
    }

    @Override
    public Screen findScreenById(Long screenId) throws JsonProcessingException {
        Screen screen=screenDao.get(screenId).orElseThrow(()-> new NoSuchScreenExistsException());
        log.info("Screen Service findScreenById request : {}",new ObjectMapper().writeValueAsString(screen));
        return screen;
    }


    @Override
    public List<Screen> getAllScreens() throws JsonProcessingException {
        List<Screen> screen= screenDao.getAll();
        log.info("Screen Service getAllScreens request : {}",new ObjectMapper().writeValueAsString(screen));
        return screen;
    }

    @Override
    public List<Screen> getScreenTypeSorted() throws JsonProcessingException {
        List<Screen> screen=screenDao.findScreenTypeSorted();
        log.info("Screen Service getAllScreens request : {}",new ObjectMapper().writeValueAsString(screen));
        return screen;
    }

    @Override
    public Screen updateScreen(Screen screen) throws JsonProcessingException {
           log.info("Screen Service Update request : {}",new ObjectMapper().writeValueAsString(screen));
            return screenDao.update(screen);
    }

    @Override
    public void deleteScreen(Long screenId) {
        screenDao.delete(screenId);
    }


}
